import tensorflow as tf


class Model:
    
    def __init__(self, batch_size, num_classes=4, lr=0.1):
        
        self.X_train = tf.placeholder(tf.float32, [batch_size,96,96,1])
        self.y_train = tf.placeholder(tf.int32, [batch_size,])
        
        # TODO: Define network
        output = tf.layers.conv2d(self.X_train, 16, 3, activation=tf.nn.relu)
        output = tf.layers.max_pooling2d(output, 3, 3)
        output = tf.layers.batch_normalization(inputs=output)
        output = tf.layers.flatten(inputs=output)
        output = tf.layers.dense(output, 40, activation=tf.nn.relu)
        output = tf.nn.dropout(output, 0.1)
        output = tf.layers.dense(output, num_classes, activation=None)

        # TODO: Loss and optimizer
        self.loss = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=output, labels=self.y_train)
        self.optimizer = tf.train.GradientDescentOptimizer(learning_rate=lr)

        # TODO: Start tensorflow session
        trainable_params = tf.trainable_variables()
        gradients = tf.gradients(self.loss, trainable_params)
        clip_gradients, _ = tf.clip_by_global_norm(gradients, 1)
        self.train_op = self.optimizer.apply_gradients(zip(clip_gradients, trainable_params))
        self.saver = tf.train.Saver()
        self.action = tf.argmax(input=tf.squeeze(output),axis=0)
        #self.action = output

    def train(self, sess, X_train, y_train):
        loss, _ = sess.run([self.loss, self.train_op], feed_dict={
                self.X_train: X_train,
                self.y_train: y_train
                })
        return loss
    
    def valid(self, sess, X_valid, y_valid):
        loss, action = sess.run([self.loss, self.action], feed_dict={
                self.X_train: X_valid,
                self.y_train: y_valid
                })
        return loss, action

    def load(self, sess, file_name):
        self.saver.restore(sess, file_name)

    def save(self, sess, file_name):
        self.saver.save(sess, file_name)

class Teacher:
    
    def __init__(self, batch_size, num_classes=4, lr=0.1):
        
        self.X_train = tf.placeholder(tf.float32, [batch_size,96,96,1])
        
        # TODO: Define network
        output = tf.layers.conv2d(self.X_train, 16, 3, activation=tf.nn.relu)
        output = tf.layers.max_pooling2d(output, 3, 3)
        output = tf.layers.batch_normalization(inputs=output)
        output = tf.layers.flatten(inputs=output)
        output = tf.layers.dense(output, 40, activation=tf.nn.relu)
        output = tf.nn.dropout(output, 0.1)
        output = tf.layers.dense(output, num_classes, activation=None)
        self.action = tf.argmax(input=tf.squeeze(output),axis=0)

    def forward(self, sess, X_train):
        action = sess.run([self.action], feed_dict={self.X_train: X_train})
        return action