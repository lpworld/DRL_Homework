import matplotlib.pyplot as plt
import numpy as np
plt.rc('text', usetex=True)
plt.rc('font', family='serif')

def bellmanequation(num):
    optimalvalue = 0
    for bet in range(0,min(num,100-num)+1):
        win = num + bet
        loss = num - bet
        sum_reward = ph * (reward[win] + gamma * value[win]) + (1 - ph) * (reward[loss] + gamma * value[loss])
        if sum_reward > optimalvalue:
            optimalvalue = sum_reward
            value[num] = sum_reward
            policy[num] = bet
            
gamma = 1
#ph = 0.25
ph = 0.55
states = 100
reward = np.zeros(states+1)
reward[states]=1
theta = 1e-5
value=np.zeros(states+1)
policy = np.zeros(states+1)
delta = 1

while delta > theta:
    delta = 0
    for i in range(1,states):
        last_value = value[i]
        bellmanequation(i)
        delta = max(delta,abs(last_value-value[i]))

plt.plot(value[:100])
plt.xlabel(r"\textbf{Number of Capitals}")
plt.ylabel(r"\textbf{Value Estimates}")
plt.title(r"\textbf{Value Iteration}")
#plt.savefig("value_iteration_25.jpg",bbox_inches='tight')
plt.savefig("value_iteration_55.jpg",bbox_inches='tight')  


