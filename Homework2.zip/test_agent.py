from __future__ import print_function

from datetime import datetime
import numpy as np
import gym
import os
import json
from model import Model
from utils import rgb2gray, id_to_action
import tensorflow as tf

tf.reset_default_graph()

def run_episode(env, sess, agent, rendering=True, max_timesteps=5000):
    
    episode_reward = 0
    step = 0

    state = env.reset()
    while True:
        
        # TODO: preprocess the state in the same way than in in your preprocessing in train_agent.py..
        state = rgb2gray(state)
        state = np.expand_dims(state, axis=3)
        state = np.expand_dims(state, axis=0)
        # TODO: get the action from your agent! If you use discretized actions you need to transform them to continuous
        # actions again. a needs to have a shape like np.array([0.0, 0.0, 0.0])
        loss, a = agent.valid(sess, state, [0])
        a = id_to_action(a)

        next_state, r, done, info = env.step(a)   
        episode_reward += r       
        state = next_state
        step += 1
        
        if rendering:
            env.render()

        if done or step > max_timesteps: 
            break
        
        print(episode_reward)

    return episode_reward


if __name__ == "__main__":

    # important: don't set rendering to False for evaluation (you may get corrupted state images from gym)
    rendering = False      
    
    n_test_episodes = 15                  # number of episodes to test
    env = gym.make('CarRacing-v0').unwrapped

    episode_rewards = []

    # TODO: load agent
    agent = Model(batch_size=1)
    with tf.Session() as sess:
        agent.load(sess, "models/agent.ckpt")

        for i in range(n_test_episodes):
            episode_reward = run_episode(env, sess, agent, rendering=rendering)
            episode_rewards.append(episode_reward)

    # save results in a dictionary and write them into a .json file
    results = dict()
    results["episode_rewards"] = episode_rewards
    results["mean"] = np.array(episode_rewards).mean()
    results["std"] = np.array(episode_rewards).std()
 
    fname = "results/results_bc_agent-%s.json" % datetime.now().strftime("%Y%m%d-%H%M%S")
    fh = open(fname, "w")
    json.dump(results, fh)
            
    env.close()
    print('... finished')
